export const BASES_ROUTE: any = {
  HOME: '/movies',
};

export const constants: any = {
  api: {
    path: 'https://api.themoviedb.org/3',
    key: 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmMjU5N2Q3NTk5NThhODEzY2FiMzZiMTZhZWVmMmZkNiIsIm5iZiI6MTczNjI4OTY5OC40LCJzdWIiOiI2NzdkYWRhMjU1YTc5Yzc2MzA3YWYwNTciLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.-hFZuSrZAEuUv5VuVF43yjFfHxNiXXZCFBfka_pmV4A',
    imagePosterEndpoint: 'https://image.tmdb.org/t/p/w500',
    imageDefault: 'https://via.placeholder.com/400x400?text=Image+Default',
  },
  version: 'V.1.0.0',

};
