export interface BreadcrumbItem {
  label: string;
  url?: string;
  active?: boolean;
}
