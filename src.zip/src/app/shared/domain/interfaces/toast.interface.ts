export interface ToastMessage {
  text: string;
  type: 'success' | 'error' | 'warning' | 'info';
}
